// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAdminAuth = require('../../../app/middleware/admin_auth');
import ExportAdminSidebar = require('../../../app/middleware/admin_sidebar');
import ExportAuth = require('../../../app/middleware/auth');
import ExportErrorHandler = require('../../../app/middleware/error_handler');
import ExportGetUser = require('../../../app/middleware/get_user');
import ExportKoaBodyparser = require('../../../app/middleware/koa_bodyparser');

declare module 'egg' {
  interface IMiddleware {
    adminAuth: typeof ExportAdminAuth;
    adminSidebar: typeof ExportAdminSidebar;
    auth: typeof ExportAuth;
    errorHandler: typeof ExportErrorHandler;
    getUser: typeof ExportGetUser;
    koaBodyparser: typeof ExportKoaBodyparser;
  }
}

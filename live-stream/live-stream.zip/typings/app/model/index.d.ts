// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportComment = require('../../../app/model/comment');
import ExportFollow = require('../../../app/model/follow');
import ExportGift = require('../../../app/model/gift');
import ExportLive = require('../../../app/model/live');
import ExportLiveGift = require('../../../app/model/live_gift');
import ExportLiveUser = require('../../../app/model/live_user');
import ExportManager = require('../../../app/model/manager');
import ExportOrder = require('../../../app/model/order');
import ExportUser = require('../../../app/model/user');

declare module 'egg' {
  interface IModel {
    Comment: ReturnType<typeof ExportComment>;
    Follow: ReturnType<typeof ExportFollow>;
    Gift: ReturnType<typeof ExportGift>;
    Live: ReturnType<typeof ExportLive>;
    LiveGift: ReturnType<typeof ExportLiveGift>;
    LiveUser: ReturnType<typeof ExportLiveUser>;
    Manager: ReturnType<typeof ExportManager>;
    Order: ReturnType<typeof ExportOrder>;
    User: ReturnType<typeof ExportUser>;
  }
}
